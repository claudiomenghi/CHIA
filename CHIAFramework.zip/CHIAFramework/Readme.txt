# RUNNING CHIA
To run chia enter the CHIA folder and type java -jar CHIA.jar

The CHIA framework offers both autocompletion (by pressing tab) and history 

# CAUTION
The convertion of an LTL formula into the corresponding automaton is based on the LTL2BA4J library.
The LTL2BA4J library uses the ltl2ba tool. ltl2ba is written in ANSI C
The compiled version of the ltl2ba library contained in CHIAltl2ba file is for OSX.

If the compiled version of the library is not compatible with your operating system 
you must download the source of ltl2ba from http://www.sable.mcgill.ca/~ebodde/rv/ltl2ba4j/ltl2ba4j.tgz
and recompile the source of ltl2ba.

For further informations see  
http://www.sable.mcgill.ca/~ebodde/rv/ltl2ba4j/